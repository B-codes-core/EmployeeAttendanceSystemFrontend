import { Component } from '@angular/core';
import { CheckInService } from '../../services/attendance.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-attendance-history',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './attendance-history.component.html',
  styleUrls: ['./attendance-history.component.css']
})
export class AttendanceHistoryComponent {
  history: any[] = [];

  constructor(service: CheckInService) {
    const employee = service.getCurrentEmployee();

    if (employee && employee.employee_id) {
      service.getAttendanceHistory(employee.employee_id).subscribe({
        next: (data) => {
          this.history = data;
        },
        error: () => {
          this.history = [];
        }
      });
    } else {
      this.history = [];
    }
  }
}
